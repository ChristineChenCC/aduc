// system.h

// Init Frequency
void InitFreq(void);

