#include <ioaduc7020.h>
#include <inarm.h>
#include "system.h"


//it's a simple delay
void Delay (unsigned long a) { while (--a!=0); }

int main()
{
  // Variables


  // Init Frequency
  InitFreq();

  // Init System
  InitSystem();


  // loop forever
  while(1) {

    // togle port P0.6
    GP0DAT ^= 0x00400000;
    Delay(10000);
  }
}
