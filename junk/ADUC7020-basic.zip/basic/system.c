//system.c
#include <ioaduc7020.h>
#include "system.h"

// Init Frequency
void InitFreq(void) {

  // Use external 32Khz crystal, PLL default value
  PLLKEY1   = 0xAA;
  PLLCON    = 0x01;
  PLLKEY2   = 0x55;

//  // Normal mode, disable the fast interrupt response, CPU clock ~ 11.272 MHz
//  POWKEY1 = 0x01;
//  POWCON  = 0x02;
//  POWKEY2 = 0xF4;

  // Normal mode, disable the fast interrupt response, CPU clock ~ 41.78 MHz
  POWKEY1 = 0x01;
  POWCON  = 0x00;
  POWKEY2 = 0xF4;


}

// Init System
void InitSystem(void) {

  // init GPIO port - toggle port P0.6

  // all as GPIO
  GP0CON = 0x0;

  // disable all GPIO
  GP0PAR = 0x11111111;

  // P0.6 as high
  GP0SET = 0x00400000;

  // P0.6 as output
  GP0DAT = 0x40000000;

}

