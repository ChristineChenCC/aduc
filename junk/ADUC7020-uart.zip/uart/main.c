
#include <ioaduc7020.h>
#include <inarm.h>
#include "uart.h"
#include "system.h"


int main()
{
  // Variables
  unsigned char ch=0;

  // Init Frequency
  InitFreq();

  // Init System
  InitSystem();

  // Init Uart at 9600 baudrate
  InitUart(9600);

  // loop forever
  while(1) {

    // echo for Uart
    ch = ReadChar();
    WriteChar(ch);
    WriteChar('*');

  }
}
