// uart.h

#ifndef __ADUC_UART
#define __ADUC_UART

// Init uart interface
void InitUart(unsigned int bdr);

// Send char
void WriteChar(unsigned char ch);

// Receive char
unsigned char ReadChar(void);

// Send string
void WriteString(unsigned char *str);

#endif


