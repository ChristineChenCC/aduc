// uart.c

#include "uart.h"
#include <ioaduc7020.h>

#define CPU_CLK   41780000

#define TEMT    0x40
#define THRE    0x20
#define	DR      0x01



// Init uart interface
void InitUart(unsigned int bdr) {

  // devisor for desired baudrate
  unsigned int divisor = CPU_CLK / (32 * bdr);

  // Setup UART function for on P1.0 and P1.1
  GP1CON = 0x011;

  // Enable access to COMDIV0 and COMDIV1 registers
  COMCON0 = 0x080;

  COMDIV0 = (unsigned char)divisor;
  COMDIV1 = (unsigned char)(divisor >> 8);

  // 1 stop bit, 8 bit lenght, no parity
  COMCON0 = 0x003;				
}

// Send char
void WriteChar(unsigned char ch) {

  // wait until COMTX is empty
  while ((COMSTA0 & TEMT) == 0);
  COMTX=ch;	
}

// Receive char
unsigned char ReadChar(void) {

  // wait until COMRX is full
  while ((COMSTA0 & DR) == 0);
  return COMRX;
}

// Send string
void WriteString(unsigned char *str) {

  // loop to the edn of the string
  for(; *str; str++)
      WriteChar(*str);
}



