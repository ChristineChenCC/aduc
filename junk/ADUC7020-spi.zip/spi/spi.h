#ifndef __ADUC_SPI
#define __ADUC_SPI

// Init SPI interface
void InitSPI(void);

// Transmit one byte via SPI
unsigned char SPITransmit(unsigned char);

#endif

