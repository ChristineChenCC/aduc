#include <ioaduc7020.h>
#include "spi.h"

// Init SPI interface
void InitSPI(void) {

  // MOSI,CLK and CS as output
  GP1DAT = 0xD0000000;

  // Pins as SPI port
  GP1CON = 0x22220000;

  // Master mode, no phase, no polarity, MSB first, Enable SPI, loopback
  SPICON = 0x0843;

  // Set devider for SPI ~ 100kHz
  SPIDIV = 0xD0;



}

// Transmit one byte via SPI
unsigned char SPITransmit(unsigned char ch) {

  // Notice!!!
  // We use loopback mode, so in real demo please clear loopback enable
  // bit (bit 11) in SPICON register

  unsigned char data;

  // Wait until transmit is under flowing
  while((SPISTA&0x04));
  // Send the data
  SPITX = ch;


  // Wait for the transfer to complete
  while(!(SPISTA&0x08));
  // Get the data received
  data = SPIRX;

  return data;

}



