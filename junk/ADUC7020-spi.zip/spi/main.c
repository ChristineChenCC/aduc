
#include <ioaduc7020.h>
#include <inarm.h>
#include "system.h"
#include "spi.h"


int main()
{
  // Variables
  unsigned char ch=0;

  // Init Frequency
  InitFreq();

  // Init System
  InitSystem();

   // Init SPI interface
   InitSPI();

   __disable_interrupt();


  // loop forever
  while(1) {

    // Transmit byte
    ch = SPITransmit(0x55);

  }
}
