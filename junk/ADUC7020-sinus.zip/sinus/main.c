
#include <ioaduc7020.h>
#include <inarm.h>
#include "system.h"
#include "adc.h"
#include "dac.h"


char sample = 0;

const static unsigned short SinTable[8] = {  0x07FF, 0x0DA7, 0x0FFF, 0x0DA7, 0x07FF, 0x0257, 0x0000, 0x0257 };


// Timer 0 Interupt source routine
#pragma vector=0x18
__irq __arm void irq_handler(void) {


  SetDACValue(SinTable[sample++]);
  if(sample==8) sample=0;

  // Clear
  T0CLRI = 0;
}

int main()
{
  // Variables

  // Init Frequency
  InitFreq();

  // Init System
  InitSystem();

  // Init ADC
  InitAdc();

  // Init Timer0
  InitTimer0();

  // Init Timer0 Interrupts
  InitInterrupts();

   // Init DAC interface
   InitDAC();

   __enable_interrupt();

  // loop forever
  while(1) {


  }
}
