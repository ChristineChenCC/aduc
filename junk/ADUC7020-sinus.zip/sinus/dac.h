// dac.h

#ifndef __ADUC_DAC
#define __ADUC_DAC

// Init Dac Interface
void InitDAC(void);

// Set DAC value
void SetDACValue(unsigned int value);

#endif


