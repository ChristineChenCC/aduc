// adc.h

#ifndef __ADUC_ADC
#define __ADUC_ADC

// Init ADC - chanel 0
void InitAdc(void);

// Init Timer0
void InitTimer0(void);

// Init Timer0 Interupts
void InitInterrupts(void);

#endif

