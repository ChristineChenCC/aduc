// adc.c

#include <ioaduc7020.h>
#include "adc.h"


// variebles
unsigned long temp=0;

void ADCpoweron(int time) {

  // power-on the ADC
  ADCCON = 0x20;

  // wait for ADC to be fully powered on
  while (time >=0)
    time--;

}

// Init ADC - chanel 0
void InitAdc(void) {

  // Power on ADC										
  ADCpoweron(20000);				
	
  // Select Chanel 0
  ADCCP  = 0x00;

  // Start conversion on , timer 0 conversion input, 8 clock aquisition time,
  // Disable ADCbusy pin, normal mode, fADC/2, single ended mode
  ADCCON = 0x06A2;					

  // Connect internal 2.5V reference to VREF pin
  REFCON = 0x01;					

}

// Init Timer0
void InitTimer0(void) {

  // 104/41780000Hz = 2.5us
  T0LD = 0x068;

  // Core clock, count down
  T0CON = 0xC0;

}

// Init Timer0 Interupts
void InitInterrupts(void) {

  // Enable ADC IRQ
  IRQEN = RTOS_TIMER_BIT;

}

