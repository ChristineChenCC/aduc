// system.h

#ifndef __ADUC_SYS
#define __ADUC_SYS

// Init Frequency
void InitFreq(void);

// Init System
void InitSystem(void);

#endif


