#include <ioaduc7020.h>
#include "dac.h"

// Init Dac Interface
void InitDAC(void) {


  // DAC configuration, range AVdd/AGND and Clocked
  DAC1CON = 0x13;

  // Start from midscale
  DAC1DAT = 0x08000000;

}

// Set DAC value
void SetDACValue(unsigned int value) {

  // Set new value
  DAC1DAT = (value << 16);

}

